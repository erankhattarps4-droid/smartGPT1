# smartGPT - Multilingual AI Chat (Prototype)

This package is a ready-to-deploy prototype of **smartGPT** — a multilingual AI chat app with free browser TTS.


## What's included
- Frontend React prototype (frontend/src)
- Serverless backend function: api/chat.js (proxies to OpenAI)
- vercel.json for easy deployment on Vercel

## Deployment (Vercel)
1. Create a GitHub repo and push this project.
2. Create a Vercel project and import from your GitHub repo.
3. In Vercel dashboard, set Environment Variable `OPENAI_API_KEY` to your OpenAI API key.
4. Deploy. The site will be available as `https://<your-project>.vercel.app`.

## Notes
- The frontend uses the browser's built-in SpeechSynthesis for free TTS.
- To improve voice quality, integrate ElevenLabs or Google TTS on the server side and return audio URLs.
- Keep your OpenAI API key secret (set it in Vercel env variables).

## License
MIT
