// App.js - smartGPT frontend prototype
import React, { useEffect, useRef, useState } from 'react';
import './styles.css';

export default function App() {
  const [messages, setMessages] = useState([
    { id: 1, role: 'assistant', text: 'مرحباً! أنا SmartGPT — كيف أساعدك اليوم؟', lang: navigator.language || 'en-US' }
  ]);
  const [input, setInput] = useState('');
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [listening, setListening] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  function speakText(text, lang) {
    if (!('speechSynthesis' in window)) return;
    const ut = new SpeechSynthesisUtterance(text);
    ut.lang = lang || (navigator.language || 'en-US');
    const voices = window.speechSynthesis.getVoices();
    const match = voices.find(v => v.lang && v.lang.startsWith((ut.lang||'en').split('-')[0]));
    if (match) ut.voice = match;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(ut);
  }

  async function sendMessage(t) {
    if (!t) return;
    const user = { id: Date.now(), role: 'user', text: t, lang: (navigator.language||'en-US') };
    setMessages(prev => [...prev, user]);
    setInput('');
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: t, lang: user.lang })
      });
      const data = await res.json();
      const reply = data.reply || '(No response)';
      const replyLang = data.lang || user.lang;
      const assistant = { id: Date.now()+1, role: 'assistant', text: reply, lang: replyLang };
      setMessages(prev => [...prev, assistant]);
      if (autoSpeak) speakText(reply, replyLang);
    } catch (e) {
      const err = { id: Date.now()+2, role: 'assistant', text: 'خطأ في الاتصال بالخادم. حاول لاحقاً.', lang: 'ar' };
      setMessages(prev => [...prev, err]);
    }
  }

  function handleSubmit(e) {
    e && e.preventDefault();
    const t = input.trim();
    if (!t) return;
    sendMessage(t);
  }

  return (
    <div className="app">
      <header className="header">
        <div className="logo">💡 <span className="brand">smartGPT</span></div>
        <div className="subtitle">مساعدك الذكي بكل اللغات</div>
      </header>
      <main className="chat-container">
        <div className="messages">
          {messages.map(m => (
            <div key={m.id} className={m.role==='assistant' ? 'msg assistant' : 'msg user'}>
              <div className="text">{m.text}</div>
              <div className="meta">{m.lang}</div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
        <form className="composer" onSubmit={handleSubmit}>
          <input value={input} onChange={e=>setInput(e.target.value)} placeholder="اكتب رسالة أو استخدم الصوت..." />
          <button type="submit">Send</button>
        </form>
      </main>
      <footer className="footer">smartGPT — multilingual AI chat (voice free)</footer>
    </div>
  );
}
