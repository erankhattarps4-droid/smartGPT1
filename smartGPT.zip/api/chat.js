// api/chat.js - serverless function for Vercel / Netlify
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const { message, lang } = req.body || {};
  if (!message) return res.status(400).json({ error: 'No message' });
  try {
    // Proxy to OpenAI - you must set OPENAI_API_KEY in your environment (Vercel dashboard)
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) return res.status(500).json({ error: 'OpenAI API key not configured' });
    const resp = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-5-mini',
        input: message
      })
    });
    const data = await resp.json();
    let reply = '(No response)';
    if (data.output && Array.isArray(data.output) && data.output[0] && data.output[0].content) {
      // best-effort extraction
      const content = data.output[0].content[0];
      reply = content.text || JSON.stringify(content);
    }
    res.json({ reply, lang: lang || 'en-US' });
  } catch (err) {
    console.error('OpenAI proxy error', err);
    res.status(500).json({ reply: 'Server error', lang: 'en-US' });
  }
}
